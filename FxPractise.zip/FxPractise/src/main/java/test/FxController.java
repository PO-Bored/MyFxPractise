package test;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

public class FxController {

    @FXML
    private TextArea result;

    @FXML
    private Button take;

    private Test test;

    @FXML
    public void initialize() {
        test = new Test();
    }

    @FXML
    void click(ActionEvent event) {
        for(String all:Test.allChar){
            result.setText(all);
        };
    }

}
